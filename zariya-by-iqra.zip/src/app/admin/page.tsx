"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import {
  LayoutDashboard,
  ShoppingBag,
  Package,
  Star,
  Mail,
  TrendingUp,
  Users,
  IndianRupee,
  Clock,
  CheckCircle2,
  Search,
  ChevronRight,
  ArrowLeft,
  ExternalLink,
  CircleDot,
  LogOut,
  Plus,
  Pencil,
  Trash2,
  X,
  Loader2,
  Save,
  Warehouse,
  CreditCard,
  Truck,
  BarChart3,
  FileText,
  Settings,
  Shield,
  Download,
  AlertTriangle,
  ArrowUpDown,
  Eye,
  Filter,
  Tag,
  DollarSign,
  PackageCheck,
  RotateCcw,
  UserCheck,
  Crown,
  Instagram,
  Image,
} from "lucide-react";
import Link from "next/link";
import { PRODUCTS, CATEGORIES, COUPONS, BRAND } from "@/data/catalog";
import { cn, formatPrice, formatNumber } from "@/lib/utils";
import { Stars } from "@/components/zariya/stars";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";

type TabId =
  | "overview"
  | "orders"
  | "products"
  | "inventory"
  | "customers"
  | "coupons"
  | "payments"
  | "shipping"
  | "reviews"
  | "reports"
  | "cms"
  | "hero-slides"
  | "subscribers"
  | "settings";

interface Stats {
  counts: { orders: number; subscribers: number; contacts: number; enquiries: number; products: number; categories: number; coupons: number };
  revenue: number;
  pending: number;
  completed: number;
  avgOrderValue: number;
  revenueByDay: { label: string; value: number }[];
  categoryStats: { name: string; count: number }[];
  paymentBreakdown: { COD: number; Online: number };
}

interface AdminOrder {
  id: string;
  orderNumber: string;
  customerName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
  items: any[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  couponCode: string | null;
  paymentMethod: string;
  status: string;
  createdAt: string;
}

const STATUS_COLORS: Record<string, string> = {
  PENDING: "bg-amber-100 text-amber-700 border-amber-200",
  CONFIRMED: "bg-blue-100 text-blue-700 border-blue-200",
  SHIPPED: "bg-purple-100 text-purple-700 border-purple-200",
  DELIVERED: "bg-emerald-100 text-emerald-700 border-emerald-200",
  CANCELLED: "bg-red-100 text-red-700 border-red-200",
};

const EASE = [0.22, 1, 0.36, 1] as const;

export default function AdminPage() {
  const router = useRouter();
  const [authChecked, setAuthChecked] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const [adminName, setAdminName] = useState("");
  const [tab, setTab] = useState<TabId>("overview");
  const [stats, setStats] = useState<Stats | null>(null);
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [subscribers, setSubscribers] = useState<any[]>([]);
  const [dbProducts, setDbProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [orderSearch, setOrderSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  // Product editor state
  const [editingProduct, setEditingProduct] = useState<any | null>(null);
  const [showProductForm, setShowProductForm] = useState(false);

  // Auth check on mount
  useEffect(() => {
    fetch("/api/admin/auth/me", { credentials: "include" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data?.authenticated) {
          setAuthenticated(true);
          setAdminName(data.admin.name);
        } else {
          router.replace("/admin/login");
        }
        setAuthChecked(true);
      })
      .catch(() => {
        router.replace("/admin/login");
        setAuthChecked(true);
      });
  }, [router]);

  const handleLogout = async () => {
    await fetch("/api/admin/auth/logout", { method: "POST", credentials: "include" });
    router.replace("/admin/login");
  };

  const loadDbProducts = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/products", { credentials: "include" });
      if (r.ok) {
        const d = await r.json();
        setDbProducts(d.products);
      }
    } catch {}
  }, []);

  const loadStats = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/stats", { credentials: "include" });
      if (r.ok) setStats(await r.json());
    } catch {}
  }, []);

  const loadOrders = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/orders", { credentials: "include" });
      if (r.ok) {
        const d = await r.json();
        setOrders(d.orders);
      }
    } catch {}
  }, []);

  const loadSubscribers = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/newsletter", { credentials: "include" });
      if (r.ok) {
        const d = await r.json();
        setSubscribers(d.subscribers);
      }
    } catch {}
  }, []);

  useEffect(() => {
    if (!authenticated) return;
    let cancelled = false;
    (async () => {
      await Promise.all([loadStats(), loadOrders(), loadSubscribers(), loadDbProducts()]);
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [authenticated, loadStats, loadOrders, loadSubscribers, loadDbProducts]);

  const updateOrderStatus = async (id: string, status: string) => {
    try {
      await fetch("/api/admin/orders", {
        method: "PATCH", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status }),
      });
      setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)));
    } catch {}
  };

  const filteredOrders = orders.filter((o) => {
    const q = orderSearch.toLowerCase();
    const matchSearch =
      !q ||
      o.orderNumber.toLowerCase().includes(q) ||
      o.customerName.toLowerCase().includes(q) ||
      o.email.toLowerCase().includes(q);
    const matchStatus = statusFilter === "ALL" || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const tabs: { id: TabId; label: string; icon: typeof LayoutDashboard; count?: number }[] = [
    { id: "overview", label: "Dashboard", icon: LayoutDashboard },
    { id: "orders", label: "Orders", icon: ShoppingBag, count: orders.length },
    { id: "products", label: "Products", icon: Package, count: dbProducts.length },
    { id: "inventory", label: "Inventory", icon: Warehouse },
    { id: "customers", label: "Customers", icon: Users, count: subscribers.length },
    { id: "coupons", label: "Coupons", icon: Tag, count: COUPONS.length },
    { id: "payments", label: "Payments", icon: CreditCard },
    { id: "shipping", label: "Shipping", icon: Truck },
    { id: "reviews", label: "Reviews", icon: Star },
    { id: "reports", label: "Reports", icon: BarChart3 },
    { id: "cms", label: "CMS", icon: FileText },
    { id: "hero-slides", label: "Hero Banners", icon: Image },
    { id: "subscribers", label: "Subscribers", icon: Mail, count: subscribers.length },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  if (!authChecked || !authenticated) {
    return (
      <div className="grid min-h-screen place-items-center bg-[hsl(352_30%_6%)]">
        <Loader2 className="h-8 w-8 animate-spin text-gold" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(352_30%_6%)] text-slate-100">
      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-white/10 bg-[hsl(352_30%_8%)]/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-gold to-champagne">
              <span className="font-serif text-lg font-bold text-primary">Z</span>
            </div>
            <div>
              <p className="font-serif text-lg font-bold leading-none">ZARIYA Admin</p>
              <p className="text-[10px] uppercase tracking-widest text-gold">
                {adminName} · Atelier Console
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden text-xs text-slate-400 sm:inline">
              Hi, {adminName.split(" ")[0]}
            </span>
            <Link
              href="/"
              className="flex items-center gap-1.5 rounded-full border border-white/15 px-3 py-1.5 text-xs font-medium text-slate-300 transition-all hover:border-gold/50 hover:text-gold"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Storefront
            </Link>
            <Link
              href="/admin/instagram"
              className="flex items-center gap-1.5 rounded-full border border-pink-500/30 bg-pink-500/10 px-3 py-1.5 text-xs font-medium text-pink-300 transition-all hover:bg-pink-500/20"
            >
              <Instagram className="h-3.5 w-3.5" /> Instagram
            </Link>
            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 rounded-full border border-white/15 px-3 py-1.5 text-xs font-medium text-slate-300 transition-all hover:border-destructive/50 hover:text-red-400"
            >
              <LogOut className="h-3.5 w-3.5" /> Logout
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-6 sm:px-6 lg:flex-row lg:py-8">
        {/* Sidebar */}
        <aside className="lg:w-60 lg:flex-none">
          <nav className="flex gap-1 overflow-x-auto rounded-2xl border border-white/10 bg-white/[0.03] p-2 lg:flex-col lg:overflow-visible">
            {tabs.map((t) => {
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "group flex flex-none items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-all",
                    tab === t.id
                      ? "bg-gradient-to-r from-gold/20 to-transparent text-gold"
                      : "text-slate-400 hover:bg-white/5 hover:text-slate-100"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span className="whitespace-nowrap">{t.label}</span>
                  {typeof t.count === "number" && (
                    <span
                      className={cn(
                        "ml-auto hidden rounded-full px-1.5 py-0.5 text-[10px] font-semibold lg:inline",
                        tab === t.id ? "bg-gold/30 text-gold" : "bg-white/10 text-slate-400"
                      )}
                    >
                      {t.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Main */}
        <main className="min-w-0 flex-1">
          {tab === "overview" && (
            <OverviewTab stats={stats} loading={loading} />
          )}

          {tab === "orders" && (
            <OrdersTab
              orders={filteredOrders}
              allCount={orders.length}
              search={orderSearch}
              setSearch={setOrderSearch}
              statusFilter={statusFilter}
              setStatusFilter={setStatusFilter}
              onUpdateStatus={updateOrderStatus}
            />
          )}

          {tab === "products" && (
            <ProductsTab
              products={dbProducts}
              onEdit={(p) => {
                setEditingProduct(p);
                setShowProductForm(true);
              }}
              onDelete={async (id) => {
                try {
                  const r = await fetch(`/api/admin/products?id=${id}`, { method: "DELETE", credentials: "include" });
                  if (r.ok) {
                    toast.success("Product deleted");
                    loadDbProducts();
                  } else {
                    toast.error("Failed to delete");
                  }
                } catch {
                  toast.error("Network error");
                }
              }}
              onAdd={() => {
                setEditingProduct(null);
                setShowProductForm(true);
              }}
              onStockUpdate={async (id, stock) => {
                try {
                  const r = await fetch("/api/admin/products", {
                    method: "PATCH", credentials: "include",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ id, stock }),
                  });
                  if (r.ok) {
                    toast.success("Stock updated");
                    loadDbProducts();
                  }
                } catch {}
              }}
            />
          )}

          {tab === "reviews" && <ReviewsTab />}

          {tab === "inventory" && <InventoryTab products={dbProducts} />}

          {tab === "customers" && <CustomersTab subscribers={subscribers} orders={orders} />}

          {tab === "payments" && <PaymentsTab orders={orders} />}

          {tab === "shipping" && <ShippingTab />}

          {tab === "reports" && <ReportsTab orders={orders} products={dbProducts} />}

          {tab === "cms" && <CMSTab />}

          {tab === "hero-slides" && <HeroSlidesTab />}

          {tab === "settings" && <SettingsTab />}

          {tab === "subscribers" && <SubscribersTab subscribers={subscribers} />}

          {tab === "coupons" && <CouponsTab />}
        </main>
      </div>

      {/* Product Form Modal */}
      {showProductForm && (
        <ProductFormModal
          product={editingProduct}
          onClose={() => {
            setShowProductForm(false);
            setEditingProduct(null);
          }}
          onSaved={() => {
            setShowProductForm(false);
            setEditingProduct(null);
            loadDbProducts();
          }}
        />
      )}
    </div>
  );
}

/* ---------------- Product Form Modal ---------------- */
function ProductFormModal({
  product,
  onClose,
  onSaved,
}: {
  product: any | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const isEdit = !!product;
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    slug: product?.slug || "",
    name: product?.name || "",
    subtitle: product?.subtitle || "",
    description: product?.description || "",
    story: product?.story || "",
    price: product?.price || "",
    compareAtPrice: product?.compareAtPrice || "",
    category: product?.category || "pherans",
    collection: product?.collection || "royal-heritage",
    fabric: product?.fabric || "",
    stock: product?.stock ?? 0,
    sku: product?.sku || "",
    careInstructions: product?.care || product?.careInstructions || "",
    shippingInfo: product?.shipping || product?.shippingInfo || "",
    images: product
      ? (Array.isArray(product.images) ? product.images.map((i: any) => i.src).join("\n") : "")
      : "",
    sizes: product
      ? (Array.isArray(product.sizes) ? product.sizes.join(", ") : "")
      : "S, M, L, XL",
    colors: product
      ? (Array.isArray(product.colors) ? product.colors.map((c: any) => `${c.name}:${c.hex}`).join(", ") : "")
      : "Deep Burgundy:#4A0E17, Royal Gold:#C5A059",
    featured: product?.featured || false,
    bestSeller: product?.bestSeller || false,
    newArrival: product?.newArrival || false,
    limitedEdition: product?.limitedEdition || false,
  });

  const set = (key: string, value: any) => setForm((f) => ({ ...f, [key]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.slug || !form.name || !form.price || !form.sku) {
      toast.error("Slug, Name, Price, SKU are required");
      return;
    }
    setSaving(true);

    const imageLines = form.images.split("\n").map((s) => s.trim()).filter(Boolean);
    const images = imageLines.map((src, i) => ({ src, alt: `${form.name} view ${i + 1}` }));
    const sizes = form.sizes.split(",").map((s) => s.trim()).filter(Boolean);
    const colors = form.colors.split(",").map((s) => s.trim()).filter(Boolean).map((s) => {
      const [name, hex] = s.split(":").map((p) => p.trim());
      return { name: name || "Color", hex: hex || "#000000" };
    });

    const payload: any = {
      slug: form.slug,
      name: form.name,
      subtitle: form.subtitle,
      description: form.description,
      story: form.story,
      price: Number(form.price),
      compareAtPrice: form.compareAtPrice ? Number(form.compareAtPrice) : null,
      category: form.category,
      collection: form.collection,
      fabric: form.fabric,
      stock: Number(form.stock),
      sku: form.sku,
      careInstructions: form.careInstructions,
      shippingInfo: form.shippingInfo,
      images,
      sizes,
      colors,
      featured: form.featured,
      bestSeller: form.bestSeller,
      newArrival: form.newArrival,
      limitedEdition: form.limitedEdition,
    };

    try {
      const method = isEdit ? "PATCH" : "POST";
      const body = isEdit ? { id: product.id, ...payload } : payload;
      const r = await fetch("/api/admin/products", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        credentials: "include",
      });
      const data = await r.json();
      if (!r.ok) {
        toast.error(data.error || "Failed to save");
        return;
      }
      toast.success(isEdit ? "Product updated" : "Product created");
      onSaved();
    } catch {
      toast.error("Network error");
    } finally {
      setSaving(false);
    }
  };

  const inputCls = "w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 outline-none transition-all focus:border-gold/50";

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto scrollbar-lux rounded-3xl border border-white/10 bg-[hsl(352_30%_8%)] p-6"
      >
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-serif text-2xl font-bold text-slate-100">
            {isEdit ? "Edit Product" : "Add New Product"}
          </h2>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full text-slate-400 hover:bg-white/10 hover:text-white">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Name *</label>
              <input value={form.name} onChange={(e) => set("name", e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Slug *</label>
              <input value={form.slug} onChange={(e) => set("slug", e.target.value)} placeholder="shahzadi-pheran" className={inputCls} />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Subtitle</label>
            <input value={form.subtitle} onChange={(e) => set("subtitle", e.target.value)} className={inputCls} />
          </div>

          <div>
            <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Description</label>
            <textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={3} className={inputCls} />
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Price (₹) *</label>
              <input type="number" value={form.price} onChange={(e) => set("price", e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Compare At (₹)</label>
              <input type="number" value={form.compareAtPrice} onChange={(e) => set("compareAtPrice", e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Stock</label>
              <input type="number" value={form.stock} onChange={(e) => set("stock", e.target.value)} className={inputCls} />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Category</label>
              <select value={form.category} onChange={(e) => set("category", e.target.value)} className={inputCls}>
                <option value="pherans">Pherans</option>
                <option value="shawls">Pashmina Shawls</option>
                <option value="suits">Embroidered Suits</option>
                <option value="kaftans">Kaftans</option>
                <option value="accessories">Accessories</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Collection</label>
              <select value={form.collection} onChange={(e) => set("collection", e.target.value)} className={inputCls}>
                <option value="royal-heritage">Royal Heritage</option>
                <option value="ivory-dreams">Ivory Dreams</option>
                <option value="midnight-noor">Midnight Noor</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">SKU *</label>
              <input value={form.sku} onChange={(e) => set("sku", e.target.value)} className={inputCls} />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Fabric</label>
            <input value={form.fabric} onChange={(e) => set("fabric", e.target.value)} placeholder="Pashmina & Silk Blend" className={inputCls} />
          </div>

          <div>
            <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Product Photos</label>
            <ImageUploader
              images={form.images}
              onChange={(val) => set("images", val)}
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Sizes (comma separated)</label>
              <input value={form.sizes} onChange={(e) => set("sizes", e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Colors (name:hex, comma)</label>
              <input value={form.colors} onChange={(e) => set("colors", e.target.value)} className={inputCls} />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Care Instructions</label>
            <textarea value={form.careInstructions} onChange={(e) => set("careInstructions", e.target.value)} rows={2} className={inputCls} />
          </div>

          <div>
            <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-400">Shipping Info</label>
            <input value={form.shippingInfo} onChange={(e) => set("shippingInfo", e.target.value)} className={inputCls} />
          </div>

          <div className="flex flex-wrap gap-3">
            {[
              ["featured", "Featured"],
              ["bestSeller", "Bestseller"],
              ["newArrival", "New Arrival"],
              ["limitedEdition", "Limited Edition"],
            ].map(([key, label]) => (
              <label key={key} className="flex cursor-pointer items-center gap-2">
                <input type="checkbox" checked={(form as any)[key]} onChange={(e) => set(key, e.target.checked)} className="h-4 w-4 accent-gold" />
                <span className="text-xs text-slate-300">{label}</span>
              </label>
            ))}
          </div>

          <div className="flex justify-end gap-3 border-t border-white/10 pt-4">
            <button type="button" onClick={onClose} className="rounded-full border border-white/15 px-5 py-2.5 text-xs font-semibold text-slate-300 hover:border-white/30">
              Cancel
            </button>
            <button type="submit" disabled={saving} className="flex items-center gap-2 rounded-full bg-gradient-to-r from-gold to-champagne px-6 py-2.5 text-xs font-semibold uppercase tracking-wide text-primary transition-all hover:scale-105 active:scale-95 disabled:opacity-60">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Saving…" : isEdit ? "Update" : "Create"}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

/* ---------------- Overview ---------------- */
function OverviewTab({ stats, loading }: { stats: Stats | null; loading: boolean }) {
  if (loading || !stats) {
    return <SkeletonGrid />;
  }
  const maxRev = Math.max(...stats.revenueByDay.map((d) => d.value), 1);
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-serif text-3xl font-bold">Overview</h1>
        <p className="mt-1 text-sm text-slate-400">A glimpse of the ZARIYA atelier today.</p>
      </div>

      {/* KPI cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          icon={IndianRupee}
          label="Total Revenue"
          value={formatPrice(stats.revenue)}
          accent="from-gold/20 to-transparent"
          iconColor="text-gold"
        />
        <KpiCard
          icon={ShoppingBag}
          label="Orders"
          value={formatNumber(stats.counts.orders)}
          sub={`${stats.pending} pending`}
          accent="from-blue-500/20 to-transparent"
          iconColor="text-blue-400"
        />
        <KpiCard
          icon={Users}
          label="Subscribers"
          value={formatNumber(stats.counts.subscribers)}
          accent="from-emerald-500/20 to-transparent"
          iconColor="text-emerald-400"
        />
        <KpiCard
          icon={TrendingUp}
          label="Avg Order Value"
          value={formatPrice(stats.avgOrderValue)}
          accent="from-purple-500/20 to-transparent"
          iconColor="text-purple-400"
        />
      </div>

      {/* Revenue chart + status */}
      <div className="grid gap-4 lg:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: EASE }}
          className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 lg:col-span-2"
        >
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-serif text-lg font-semibold">Revenue · Last 7 Days</h2>
            <span className="text-xs text-slate-400">Daily totals</span>
          </div>
          <div className="flex h-48 items-end justify-between gap-2">
            {stats.revenueByDay.map((d, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-2">
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: `${(d.value / maxRev) * 100}%` }}
                  transition={{ duration: 0.6, delay: i * 0.06, ease: EASE }}
                  className="w-full max-w-[40px] rounded-t-md bg-gradient-to-t from-gold/40 to-gold"
                  style={{ minHeight: d.value > 0 ? 8 : 2 }}
                />
                <span className="text-[10px] text-slate-400">{d.label}</span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1, ease: EASE }}
          className="rounded-2xl border border-white/10 bg-white/[0.03] p-5"
        >
          <h2 className="mb-4 font-serif text-lg font-semibold">Order Status</h2>
          <div className="space-y-3">
            <StatusRow icon={Clock} label="Pending" value={stats.pending} color="text-amber-400" />
            <StatusRow icon={CheckCircle2} label="Completed" value={stats.completed} color="text-emerald-400" />
            <div className="my-3 h-px bg-white/10" />
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Payment</p>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-300">COD</span>
              <span className="font-semibold text-gold">{stats.paymentBreakdown.COD}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-300">Online</span>
              <span className="font-semibold text-gold">{stats.paymentBreakdown.Online}</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Category distribution */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2, ease: EASE }}
        className="rounded-2xl border border-white/10 bg-white/[0.03] p-5"
      >
        <h2 className="mb-4 font-serif text-lg font-semibold">Catalog by Category</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {stats.categoryStats.map((c) => (
            <div key={c.name} className="rounded-xl border border-white/5 bg-white/[0.02] p-3">
              <p className="text-xs text-slate-400">{c.name}</p>
              <p className="mt-1 font-serif text-2xl font-bold text-gold">{c.count}</p>
              <p className="text-[10px] text-slate-500">pieces</p>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

function KpiCard({
  icon: Icon,
  label,
  value,
  sub,
  accent,
  iconColor,
}: {
  icon: typeof IndianRupee;
  label: string;
  value: string;
  sub?: string;
  accent: string;
  iconColor: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: EASE }}
      className={cn("relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-5")}
    >
      <div className={cn("pointer-events-none absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br blur-2xl", accent)} />
      <div className="relative">
        <Icon className={cn("h-5 w-5", iconColor)} />
        <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">{label}</p>
        <p className="mt-1 font-serif text-2xl font-bold">{value}</p>
        {sub && <p className="mt-0.5 text-[11px] text-slate-500">{sub}</p>}
      </div>
    </motion.div>
  );
}

function StatusRow({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: typeof Clock;
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Icon className={cn("h-4 w-4", color)} />
        <span className="text-sm text-slate-300">{label}</span>
      </div>
      <span className="font-semibold">{value}</span>
    </div>
  );
}

function SkeletonGrid() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-28 animate-pulse rounded-2xl border border-white/10 bg-white/[0.03]" />
        ))}
      </div>
      <div className="h-64 animate-pulse rounded-2xl border border-white/10 bg-white/[0.03]" />
    </div>
  );
}

/* ---------------- Orders ---------------- */
function OrdersTab({
  orders,
  allCount,
  search,
  setSearch,
  statusFilter,
  setStatusFilter,
  onUpdateStatus,
}: {
  orders: AdminOrder[];
  allCount: number;
  search: string;
  setSearch: (v: string) => void;
  statusFilter: string;
  setStatusFilter: (v: string) => void;
  onUpdateStatus: (id: string, status: string) => void;
}) {
  const statuses = ["ALL", "PENDING", "CONFIRMED", "SHIPPED", "DELIVERED", "CANCELLED"];
  const [selectedOrder, setSelectedOrder] = useState<AdminOrder | null>(null);
  const [page, setPage] = useState(1);
  const perPage = 10;
  const totalPages = Math.ceil(orders.length / perPage);
  const paginatedOrders = orders.slice((page - 1) * perPage, page * perPage);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-serif text-3xl font-bold">Orders</h1>
        <p className="mt-1 text-sm text-slate-400">{allCount} total · manage and fulfil</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by order #, name, email…"
            className="w-full rounded-xl border border-white/10 bg-white/[0.03] py-2.5 pl-10 pr-4 text-sm outline-none transition-all placeholder:text-slate-500 focus:border-gold/50"
          />
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {statuses.map((s) => (
            <button
              key={s}
              onClick={() => { setStatusFilter(s); setPage(1); }}
              className={cn(
                "flex-none rounded-full px-3 py-1.5 text-xs font-medium transition-all",
                statusFilter === s
                  ? "bg-gold text-primary"
                  : "border border-white/10 text-slate-400 hover:text-slate-100"
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      {orders.length === 0 ? (
        <EmptyState
          icon={ShoppingBag}
          title="No orders yet"
          subtitle="Orders placed on the storefront will appear here."
        />
      ) : (
        <>
          <div className="space-y-3">
            {paginatedOrders.map((o, i) => (
              <motion.div
                key={o.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: i * 0.03, ease: EASE }}
                className="rounded-2xl border border-white/10 bg-white/[0.03] p-4"
              >
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-semibold text-gold">{o.orderNumber}</span>
                      <span
                        className={cn(
                          "rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                          STATUS_COLORS[o.status] || "bg-slate-100 text-slate-700 border-slate-200"
                        )}
                      >
                        {o.status}
                      </span>
                    </div>
                    <p className="mt-1 truncate text-sm font-medium text-slate-200">{o.customerName}</p>
                    <p className="truncate text-xs text-slate-500">
                      {o.email} · {o.phone}
                    </p>
                    <p className="mt-0.5 text-[11px] text-slate-500">
                      {new Date(o.createdAt).toLocaleString("en-IN", {
                        day: "numeric",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}{" "}
                      · {o.items.length} item{o.items.length !== 1 ? "s" : ""} · {o.paymentMethod}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 sm:flex-col sm:items-end">
                    <span className="font-serif text-xl font-bold text-gold">{formatPrice(o.total)}</span>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => setSelectedOrder(o)}
                        className="flex items-center gap-1 rounded-lg bg-white/5 px-2.5 py-1.5 text-[10px] font-semibold text-slate-300 hover:bg-gold/20 hover:text-gold"
                      >
                        <Eye className="h-3 w-3" /> View
                      </button>
                      <select
                        value={o.status}
                        onChange={(e) => onUpdateStatus(o.id, e.target.value)}
                        className="rounded-lg border border-white/10 bg-[hsl(352_30%_10%)] px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:border-gold/50"
                      >
                        {["PENDING", "CONFIRMED", "SHIPPED", "DELIVERED", "CANCELLED"].map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 pt-4">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="rounded-full border border-white/10 px-3 py-1.5 text-xs font-semibold text-slate-300 disabled:opacity-40 hover:border-gold/50"
              >
                ← Prev
              </button>
              <span className="text-xs text-slate-400">
                Page {page} of {totalPages}
              </span>
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="rounded-full border border-white/10 px-3 py-1.5 text-xs font-semibold text-slate-300 disabled:opacity-40 hover:border-gold/50"
              >
                Next →
              </button>
            </div>
          )}
        </>
      )}

      {/* Order Details Modal */}
      {selectedOrder && (
        <OrderDetailsModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
          onUpdateStatus={onUpdateStatus}
        />
      )}
    </div>
  );
}

/* ---------------- Order Details Modal ---------------- */
function OrderDetailsModal({
  order,
  onClose,
  onUpdateStatus,
}: {
  order: AdminOrder;
  onClose: () => void;
  onUpdateStatus: (id: string, status: string) => void;
}) {
  const STATUS_STEPS = [
    { key: "PENDING", label: "Order Placed", icon: Clock },
    { key: "CONFIRMED", label: "Confirmed", icon: CheckCircle2 },
    { key: "SHIPPED", label: "Dispatched", icon: Truck },
    { key: "DELIVERED", label: "Delivered", icon: PackageCheck },
  ];
  const stepIdx = STATUS_STEPS.findIndex((s) => s.key === order.status);
  const isCancelled = order.status === "CANCELLED";

  const handlePrint = () => {
    const printContent = `
      <html><head><title>Invoice - ${order.orderNumber}</title>
      <style>body{font-family:Georgia,serif;padding:40px;color:#1E1E1E}
      h1{color:#4A0E17}table{width:100%;border-collapse:collapse;margin:20px 0}
      th,td{border:1px solid #ddd;padding:8px;text-align:left}th{background:#FAF8F5}
      .total{font-weight:bold;font-size:18px}.gold{color:#C5A059}</style></head><body>
      <h1>ZARIYA by IQRA</h1>
      <p>Timeless Kashmiri Elegance · Estd. 2009</p>
      <hr>
      <h2>Invoice: ${order.orderNumber}</h2>
      <p><b>Customer:</b> ${order.customerName}<br>
      <b>Email:</b> ${order.email}<br>
      <b>Phone:</b> ${order.phone}<br>
      <b>Address:</b> ${order.address}, ${order.city}, ${order.state} ${order.pincode}, ${order.country}<br>
      <b>Date:</b> ${new Date(order.createdAt).toLocaleDateString("en-IN")}<br>
      <b>Payment:</b> ${order.paymentMethod} · <b>Status:</b> ${order.status}</p>
      <table><thead><tr><th>Item</th><th>Color</th><th>Size</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>
      ${order.items.map((it: any) => `<tr><td>${it.name}</td><td>${it.color || ""}</td><td>${it.size || ""}</td><td>${it.quantity}</td><td>₹${(it.price || 0).toLocaleString("en-IN")}</td><td>₹${((it.price || 0) * (it.quantity || 1)).toLocaleString("en-IN")}</td></tr>`).join("")}
      </tbody></table>
      <p>Subtotal: ₹${(order.subtotal || 0).toLocaleString("en-IN")}<br>
      ${order.discount > 0 ? `Discount: -₹${(order.discount || 0).toLocaleString("en-IN")}<br>` : ""}
      Shipping: Free<br>
      <span class="total gold">Total: ₹${(order.total || 0).toLocaleString("en-IN")}</span></p>
      <hr><p style="text-align:center;color:#999;font-size:12px">Thank you for choosing ZARIYA by IQRA · Handcrafted in Kashmir</p>
      </body></html>
    `;
    const w = window.open("", "_blank");
    if (w) {
      w.document.write(printContent);
      w.document.close();
      w.print();
    }
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto scrollbar-lux rounded-3xl border border-white/10 bg-[hsl(352_30%_8%)] p-6"
      >
        {/* Header */}
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h2 className="font-serif text-xl font-bold text-slate-100">Order Details</h2>
            <p className="font-mono text-sm text-gold">{order.orderNumber}</p>
          </div>
          <div className="flex gap-2">
            <button onClick={handlePrint} className="flex items-center gap-1.5 rounded-full border border-white/15 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:border-gold/50 hover:text-gold">
              <Download className="h-3.5 w-3.5" /> Invoice
            </button>
            <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full text-slate-400 hover:bg-white/10 hover:text-white">
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Status Timeline */}
        <div className="mb-6 rounded-2xl border border-white/10 bg-white/[0.02] p-4">
          <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-slate-400">Order Timeline</h3>
          {isCancelled ? (
            <div className="rounded-xl border border-red-500/30 bg-red-500/5 p-3 text-center">
              <p className="font-serif text-sm font-semibold text-red-400">Order Cancelled</p>
            </div>
          ) : (
            <div className="relative flex justify-between">
              {/* Progress line */}
              <div className="absolute left-5 top-5 h-0.5 bg-white/10" style={{ width: "calc(100% - 40px)" }} />
              <div
                className="absolute left-5 top-5 h-0.5 bg-gold transition-all"
                style={{ width: `calc((100% - 40px) * ${Math.max(0, stepIdx)} / ${STATUS_STEPS.length - 1})` }}
              />
              {STATUS_STEPS.map((step, i) => {
                const Icon = step.icon;
                const done = i <= stepIdx;
                const active = i === stepIdx;
                return (
                  <div key={step.key} className="relative z-10 flex flex-col items-center gap-1">
                    <div className={cn(
                      "grid h-10 w-10 place-items-center rounded-full border-2 transition-all",
                      done ? "border-gold bg-gold text-primary" : "border-white/20 bg-[hsl(352_30%_8%)] text-slate-500",
                      active && "ring-4 ring-gold/20"
                    )}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <span className={cn("text-[10px] font-medium", done ? "text-gold" : "text-slate-500")}>{step.label}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Customer + Shipping */}
        <div className="mb-6 grid gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Customer</h3>
            <p className="text-sm font-medium text-slate-100">{order.customerName}</p>
            <p className="text-xs text-slate-400">{order.email}</p>
            <p className="text-xs text-slate-400">{order.phone}</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Shipping Address</h3>
            <p className="text-xs text-slate-300">{order.address}</p>
            <p className="text-xs text-slate-300">{order.city}, {order.state} {order.pincode}</p>
            <p className="text-xs text-slate-300">{order.country}</p>
          </div>
        </div>

        {/* Items */}
        <div className="mb-6 rounded-2xl border border-white/10 bg-white/[0.02] p-4">
          <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-slate-400">Items ({order.items.length})</h3>
          <div className="space-y-2">
            {order.items.map((it: any, i: number) => (
              <div key={i} className="flex items-center gap-3 rounded-lg bg-white/[0.02] p-2">
                <img src={it.image} alt={it.name} className="h-12 w-10 rounded object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-slate-100">{it.name}</p>
                  <p className="text-xs text-slate-500">{it.color} · {it.size} · × {it.quantity}</p>
                </div>
                <span className="text-sm font-semibold text-gold">{formatPrice((it.price || 0) * (it.quantity || 1))}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Summary + Payment */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Payment</h3>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between"><span className="text-slate-400">Method</span><span className="font-medium text-slate-200">{order.paymentMethod}</span></div>
              <div className="flex justify-between"><span className="text-slate-400">Status</span>
                <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-bold uppercase", order.status === "DELIVERED" ? "bg-emerald-500/15 text-emerald-400" : order.status === "CANCELLED" ? "bg-red-500/15 text-red-400" : "bg-amber-500/15 text-amber-400")}>{order.status}</span>
              </div>
              {order.couponCode && <div className="flex justify-between"><span className="text-slate-400">Coupon</span><span className="font-medium text-gold">{order.couponCode}</span></div>}
            </div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Order Summary</h3>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between"><span className="text-slate-400">Subtotal</span><span className="text-slate-200">{formatPrice(order.subtotal)}</span></div>
              {order.discount > 0 && <div className="flex justify-between text-emerald-400"><span>Discount</span><span>−{formatPrice(order.discount)}</span></div>}
              <div className="flex justify-between"><span className="text-slate-400">Shipping</span><span className="text-emerald-400">Free</span></div>
              <div className="flex justify-between border-t border-white/10 pt-1"><span className="font-semibold text-slate-100">Total</span><span className="font-serif text-lg font-bold text-gold">{formatPrice(order.total)}</span></div>
            </div>
          </div>
        </div>

        {/* Status update */}
        <div className="mt-5 flex items-center gap-3 border-t border-white/10 pt-4">
          <span className="text-xs text-slate-400">Update status:</span>
          <select
            value={order.status}
            onChange={(e) => { onUpdateStatus(order.id, e.target.value); onClose(); }}
            className="rounded-lg border border-white/10 bg-[hsl(352_30%_10%)] px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-gold/50"
          >
            {["PENDING", "CONFIRMED", "SHIPPED", "DELIVERED", "CANCELLED"].map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
      </motion.div>
    </div>
  );
}

/* ---------------- Products ---------------- */
function ProductsTab({
  products,
  onEdit,
  onDelete,
  onAdd,
  onStockUpdate,
}: {
  products: any[];
  onEdit: (p: any) => void;
  onDelete: (id: string) => void;
  onAdd: () => void;
  onStockUpdate: (id: string, stock: number) => void;
}) {
  const [search, setSearch] = useState("");
  const filtered = products.filter(
    (p) =>
      !search ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase()) ||
      p.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-serif text-3xl font-bold">Products</h1>
          <p className="mt-1 text-sm text-slate-400">
            {products.length} pieces · manage inventory, prices & details
          </p>
        </div>
        <button
          onClick={onAdd}
          className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-gold to-champagne px-4 py-2 text-xs font-semibold uppercase tracking-wide text-primary transition-all hover:scale-105 active:scale-95"
        >
          <Plus className="h-4 w-4" /> Add Product
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, SKU, or category…"
          className="w-full rounded-xl border border-white/10 bg-white/[0.03] py-2.5 pl-10 pr-4 text-sm outline-none transition-all placeholder:text-slate-500 focus:border-gold/50"
        />
      </div>

      {/* Product grid */}
      {filtered.length === 0 ? (
        <div className="grid place-items-center rounded-2xl border border-dashed border-white/10 py-16 text-center">
          <Package className="h-10 w-10 text-slate-600" />
          <h3 className="mt-3 font-serif text-lg font-semibold text-slate-300">No products</h3>
          <p className="mt-1 text-xs text-slate-500">Add your first product to begin.</p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p, i) => {
            const img = Array.isArray(p.images) ? p.images[0]?.src : null;
            return (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: i * 0.03, ease: EASE }}
                className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03]"
              >
                <div className="flex gap-3 p-3">
                  <img
                    src={img || "/images/placeholder.png"}
                    alt={p.name}
                    loading="lazy"
                    className="h-20 w-16 flex-none rounded-lg object-cover"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-[10px] uppercase tracking-wide text-gold">{p.category}</p>
                    <h3 className="truncate font-serif text-sm font-semibold text-slate-100">{p.name}</h3>
                    <p className="truncate text-xs text-slate-400">{p.subtitle}</p>
                    <div className="mt-1.5 flex items-center justify-between">
                      <span className="font-semibold text-gold">{formatPrice(p.price)}</span>
                      <span className={cn("text-[11px] font-medium", p.stock <= 5 ? "text-red-400" : "text-emerald-400")}>
                        Stock: {p.stock}
                      </span>
                    </div>
                  </div>
                </div>
                {/* Quick stock editor */}
                <div className="flex items-center gap-2 border-t border-white/5 bg-white/[0.02] px-3 py-2">
                  <span className="text-[10px] uppercase text-slate-500">Stock:</span>
                  <input
                    type="number"
                    defaultValue={p.stock}
                    min={0}
                    onBlur={(e) => {
                      const v = Number(e.target.value);
                      if (v !== p.stock) onStockUpdate(p.id, v);
                    }}
                    className="w-16 rounded-md border border-white/10 bg-white/5 px-2 py-1 text-xs text-slate-200 outline-none focus:border-gold/50"
                  />
                  <div className="ml-auto flex gap-1">
                    <button
                      onClick={() => onEdit(p)}
                      aria-label="Edit product"
                      className="grid h-7 w-7 place-items-center rounded-md text-slate-400 transition-colors hover:bg-gold/20 hover:text-gold"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Delete "${p.name}"? This cannot be undone.`)) onDelete(p.id);
                      }}
                      aria-label="Delete product"
                      className="grid h-7 w-7 place-items-center rounded-md text-slate-400 transition-colors hover:bg-red-500/20 hover:text-red-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------- Reviews ---------------- */
function ReviewsTab() {
  const allReviews = PRODUCTS.flatMap((p) =>
    p.reviews.map((r) => ({ ...r, productName: p.name, productSlug: p.slug, status: "approved" }))
  );
  const [reviews, setReviews] = useState(allReviews);
  const [search, setSearch] = useState("");
  const [ratingFilter, setRatingFilter] = useState("all");

  const filtered = reviews.filter((r) => {
    const matchSearch = !search || r.author.toLowerCase().includes(search.toLowerCase()) || r.title.toLowerCase().includes(search.toLowerCase()) || r.productName.toLowerCase().includes(search.toLowerCase());
    const matchRating = ratingFilter === "all" || r.rating === Number(ratingFilter);
    return matchSearch && matchRating;
  });

  const handleApprove = async (id: string) => {
    toast.success("Review approved");
    setReviews((prev) => prev.map((r) => r.id === id ? { ...r, status: "approved" } : r));
  };
  const handleReject = async (id: string) => {
    toast.success("Review rejected");
    setReviews((prev) => prev.map((r) => r.id === id ? { ...r, status: "rejected" } : r));
  };
  const handleDelete = async (id: string) => {
    if (!confirm("Delete this review?")) return;
    toast.success("Review deleted");
    setReviews((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-serif text-3xl font-bold">Reviews</h1>
        <p className="mt-1 text-sm text-slate-400">{filtered.length} customer reviews · moderate & manage</p>
      </div>

      {/* Search + filter */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search reviews…" className="w-full rounded-xl border border-white/10 bg-white/[0.03] py-2.5 pl-10 pr-4 text-sm outline-none focus:border-gold/50" />
        </div>
        <div className="flex gap-1.5">
          {["all", "5", "4", "3"].map((f) => (
            <button key={f} onClick={() => setRatingFilter(f)} className={cn("rounded-full px-3 py-1.5 text-xs font-semibold uppercase tracking-wide", ratingFilter === f ? "bg-gold text-primary" : "border border-white/10 text-slate-400")}>
              {f === "all" ? "All" : `${f}★`}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {filtered.length === 0 ? (
          <EmptyState icon={Star} title="No reviews found" subtitle="Try adjusting your search or filters." />
        ) : (
          filtered.slice(0, 30).map((r, i) => (
            <motion.div
              key={r.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.02, ease: EASE }}
              className="rounded-2xl border border-white/10 bg-white/[0.03] p-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <Stars rating={r.rating} size={13} />
                    <span className="text-xs text-slate-400">{r.author}</span>
                    {r.verified && (
                      <span className="rounded-full bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-semibold text-emerald-400">VERIFIED</span>
                    )}
                    <span className={cn("rounded-full px-1.5 py-0.5 text-[9px] font-semibold uppercase", r.status === "approved" ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400")}>
                      {r.status}
                    </span>
                  </div>
                  <h3 className="mt-1 font-serif text-sm font-semibold text-slate-100">{r.title}</h3>
                  <p className="mt-1 text-xs leading-relaxed text-slate-400">{r.body}</p>
                  <p className="mt-1.5 text-[10px] text-slate-500">
                    on <span className="text-gold">{r.productName}</span>
                    {r.location ? ` · ${r.location}` : ""}
                  </p>
                </div>
                <div className="flex flex-none flex-col gap-1">
                  <button onClick={() => handleApprove(r.id)} className="rounded-lg border border-emerald-500/30 px-2.5 py-1 text-[10px] font-semibold text-emerald-400 transition-colors hover:bg-emerald-500/10">
                    <CheckCircle2 className="mr-1 inline h-3 w-3" />Approve
                  </button>
                  <button onClick={() => handleReject(r.id)} className="rounded-lg border border-amber-500/30 px-2.5 py-1 text-[10px] font-semibold text-amber-400 transition-colors hover:bg-amber-500/10">
                    Reject
                  </button>
                  <button onClick={() => handleDelete(r.id)} className="rounded-lg border border-red-500/30 px-2.5 py-1 text-[10px] font-semibold text-red-400 transition-colors hover:bg-red-500/10">
                    <Trash2 className="mr-1 inline h-3 w-3" />Delete
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}

/* ---------------- Subscribers ---------------- */
function SubscribersTab({ subscribers }: { subscribers: any[] }) {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-serif text-3xl font-bold">Subscribers</h1>
        <p className="mt-1 text-sm text-slate-400">{subscribers.length} in the Zariya Circle</p>
      </div>
      {subscribers.length === 0 ? (
        <EmptyState icon={Mail} title="No subscribers yet" subtitle="Newsletter signups will appear here." />
      ) : (
        <div className="overflow-hidden rounded-2xl border border-white/10">
          <table className="w-full text-sm">
            <thead className="bg-white/[0.05] text-xs uppercase tracking-wide text-slate-400">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Email</th>
                <th className="px-4 py-3 text-left font-medium">Name</th>
                <th className="px-4 py-3 text-left font-medium">Joined</th>
              </tr>
            </thead>
            <tbody>
              {subscribers.map((s, i) => (
                <tr key={s.id} className={cn("border-t border-white/5", i % 2 === 0 ? "bg-white/[0.01]" : "")}>
                  <td className="px-4 py-3 text-slate-200">{s.email}</td>
                  <td className="px-4 py-3 text-slate-400">{s.name || "—"}</td>
                  <td className="px-4 py-3 text-slate-500">
                    {new Date(s.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ---------------- Coupons ---------------- */
function CouponsTab() {
  const [coupons, setCoupons] = useState<any[]>(COUPONS);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);

  const loadCoupons = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/coupons", { credentials: "include" });
      if (r.ok) {
        const d = await r.json();
        if (d.coupons?.length) setCoupons(d.coupons);
      }
    } catch {}
    setLoading(false);
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      await loadCoupons();
      if (cancelled) return;
    })();
    return () => { cancelled = true; };
  }, [loadCoupons]);

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this coupon?")) return;
    try {
      await fetch(`/api/admin/coupons?id=${id}`, { method: "DELETE", credentials: "include" });
      toast.success("Coupon deleted");
      loadCoupons();
    } catch { toast.error("Failed to delete"); }
  };

  const toggleActive = async (id: string, active: boolean) => {
    try {
      await fetch("/api/admin/coupons", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, active: !active }),
        credentials: "include",
      });
      toast.success(active ? "Coupon deactivated" : "Coupon activated");
      loadCoupons();
    } catch {}
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-serif text-3xl font-bold">Coupons</h1>
          <p className="mt-1 text-sm text-slate-400">{coupons.length} discount codes</p>
        </div>
        <button
          onClick={() => { setEditing(null); setShowForm(true); }}
          className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-gold to-champagne px-4 py-2 text-xs font-semibold uppercase tracking-wide text-primary"
        >
          <Plus className="h-4 w-4" /> Add Coupon
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {coupons.map((c, i) => (
          <motion.div
            key={c.id || c.code}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.05, ease: EASE }}
            className="relative overflow-hidden rounded-2xl border border-gold/20 bg-gradient-to-br from-gold/10 to-transparent p-5"
          >
            <div className="pointer-events-none absolute -right-4 -top-4 h-20 w-20 rounded-full bg-gold/10 blur-2xl" />
            <div className="flex items-start justify-between">
              <p className="font-mono text-lg font-bold text-gold">{c.code}</p>
              {c.id && (
                <span className={cn("rounded-full px-2 py-0.5 text-[9px] font-bold uppercase", c.active !== false ? "bg-emerald-500/15 text-emerald-400" : "bg-slate-500/15 text-slate-400")}>
                  {c.active !== false ? "Active" : "Inactive"}
                </span>
              )}
            </div>
            <p className="mt-2 font-serif text-3xl font-bold">
              {c.type === "percent" ? `${c.value}%` : formatPrice(c.value)}
              <span className="text-sm font-normal text-slate-400"> off</span>
            </p>
            <p className="mt-2 text-xs text-slate-400">{c.description}</p>
            <p className="mt-3 text-[10px] uppercase tracking-wide text-slate-500">
              Min order: {formatPrice(c.minOrder)}
            </p>
            {c.id && (
              <div className="mt-3 flex gap-2 border-t border-white/5 pt-3">
                <button
                  onClick={() => { setEditing(c); setShowForm(true); }}
                  className="flex items-center gap-1 rounded-md bg-white/5 px-2 py-1 text-[10px] text-slate-300 hover:bg-gold/20 hover:text-gold"
                >
                  <Pencil className="h-3 w-3" /> Edit
                </button>
                <button
                  onClick={() => toggleActive(c.id, c.active !== false)}
                  className="flex items-center gap-1 rounded-md bg-white/5 px-2 py-1 text-[10px] text-slate-300 hover:bg-amber-500/20 hover:text-amber-400"
                >
                  {c.active !== false ? "Deactivate" : "Activate"}
                </button>
                <button
                  onClick={() => handleDelete(c.id)}
                  className="flex items-center gap-1 rounded-md bg-white/5 px-2 py-1 text-[10px] text-slate-300 hover:bg-red-500/20 hover:text-red-400"
                >
                  <Trash2 className="h-3 w-3" /> Delete
                </button>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {showForm && (
        <CouponFormModal
          coupon={editing}
          onClose={() => { setShowForm(false); setEditing(null); }}
          onSaved={() => { setShowForm(false); setEditing(null); loadCoupons(); }}
        />
      )}
    </div>
  );
}

function CouponFormModal({ coupon, onClose, onSaved }: { coupon: any | null; onClose: () => void; onSaved: () => void }) {
  const isEdit = !!coupon;
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    code: coupon?.code || "",
    type: coupon?.type || "percent",
    value: coupon?.value || 10,
    minOrder: coupon?.minOrder || 0,
    description: coupon?.description || "",
    active: coupon?.active !== false,
  });
  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.code || !form.value) { toast.error("Code and value are required"); return; }
    setSaving(true);
    try {
      const method = isEdit ? "PATCH" : "POST";
      const body = isEdit ? { id: coupon.id, ...form } : form;
      const r = await fetch("/api/admin/coupons", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        credentials: "include",
      });
      const data = await r.json();
      if (!r.ok) { toast.error(data.error || "Failed"); return; }
      toast.success(isEdit ? "Coupon updated" : "Coupon created");
      onSaved();
    } catch { toast.error("Network error"); }
    finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-md rounded-3xl border border-white/10 bg-[hsl(352_30%_8%)] p-6">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-serif text-xl font-bold">{isEdit ? "Edit Coupon" : "Add Coupon"}</h2>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full text-slate-400 hover:bg-white/10"><X className="h-4 w-4" /></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Code *</label>
            <input value={form.code} onChange={(e) => set("code", e.target.value.toUpperCase())} placeholder="ZARIYA10" className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 font-mono text-sm text-slate-100 outline-none focus:border-gold/50" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Type</label>
              <select value={form.type} onChange={(e) => set("type", e.target.value)} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 outline-none focus:border-gold/50">
                <option value="percent">Percentage (%)</option>
                <option value="fixed">Fixed Amount (₹)</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Value *</label>
              <input type="number" value={form.value} onChange={(e) => set("value", Number(e.target.value))} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 outline-none focus:border-gold/50" />
            </div>
          </div>
          <div>
            <label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Min Order (₹)</label>
            <input type="number" value={form.minOrder} onChange={(e) => set("minOrder", Number(e.target.value))} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 outline-none focus:border-gold/50" />
          </div>
          <div>
            <label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Description</label>
            <input value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="10% off first order" className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 outline-none focus:border-gold/50" />
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.active} onChange={(e) => set("active", e.target.checked)} className="h-4 w-4 accent-gold" />
            <span className="text-xs text-slate-300">Active</span>
          </label>
          <div className="flex justify-end gap-3 border-t border-white/10 pt-4">
            <button type="button" onClick={onClose} className="rounded-full border border-white/15 px-5 py-2 text-xs font-semibold text-slate-300">Cancel</button>
            <button type="submit" disabled={saving} className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-gold to-champagne px-6 py-2 text-xs font-semibold text-primary disabled:opacity-60">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Saving…" : isEdit ? "Update" : "Create"}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function EmptyState({
  icon: Icon,
  title,
  subtitle,
}: {
  icon: typeof Mail;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="grid place-items-center rounded-2xl border border-dashed border-white/10 bg-white/[0.02] py-16 text-center">
      <Icon className="h-10 w-10 text-slate-600" />
      <h3 className="mt-3 font-serif text-lg font-semibold text-slate-300">{title}</h3>
      <p className="mt-1 max-w-xs text-sm text-slate-500">{subtitle}</p>
    </div>
  );
}

/* ---------------- Inventory ---------------- */
function InventoryTab({ products }: { products: any[] }) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "low" | "out">("all");

  const lowStockThreshold = 5;
  const filtered = products.filter((p) => {
    const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.sku?.toLowerCase().includes(search.toLowerCase());
    const matchFilter =
      filter === "all" ||
      (filter === "low" && p.stock > 0 && p.stock <= lowStockThreshold) ||
      (filter === "out" && p.stock === 0);
    return matchSearch && matchFilter;
  });

  const totalStock = products.reduce((s, p) => s + (p.stock || 0), 0);
  const lowCount = products.filter((p) => p.stock > 0 && p.stock <= lowStockThreshold).length;
  const outCount = products.filter((p) => p.stock === 0).length;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-serif text-3xl font-bold">Inventory</h1>
        <p className="mt-1 text-sm text-slate-400">Stock overview · low stock · out of stock</p>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <PackageCheck className="h-5 w-5 text-emerald-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Total Stock Units</p>
          <p className="font-serif text-2xl font-bold">{totalStock}</p>
        </div>
        <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-5">
          <AlertTriangle className="h-5 w-5 text-amber-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Low Stock</p>
          <p className="font-serif text-2xl font-bold text-amber-400">{lowCount}</p>
        </div>
        <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-5">
          <AlertTriangle className="h-5 w-5 text-red-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Out of Stock</p>
          <p className="font-serif text-2xl font-bold text-red-400">{outCount}</p>
        </div>
      </div>

      {/* Search + filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name or SKU…" className="w-full rounded-xl border border-white/10 bg-white/[0.03] py-2.5 pl-10 pr-4 text-sm outline-none focus:border-gold/50" />
        </div>
        <div className="flex gap-1.5">
          {(["all", "low", "out"] as const).map((f) => (
            <button key={f} onClick={() => setFilter(f)} className={cn("rounded-full px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wide transition-all", filter === f ? "bg-gold text-primary" : "border border-white/10 text-slate-400 hover:text-slate-100")}>
              {f === "all" ? "All" : f === "low" ? "Low Stock" : "Out of Stock"}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-2xl border border-white/10">
        <table className="w-full text-sm">
          <thead className="bg-white/[0.05] text-xs uppercase tracking-wide text-slate-400">
            <tr>
              <th className="px-4 py-3 text-left font-medium">Product</th>
              <th className="px-4 py-3 text-left font-medium">SKU</th>
              <th className="px-4 py-3 text-center font-medium">Stock</th>
              <th className="px-4 py-3 text-center font-medium">Status</th>
              <th className="px-4 py-3 text-right font-medium">Price</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p, i) => (
              <tr key={p.id} className={cn("border-t border-white/5", i % 2 === 0 ? "bg-white/[0.01]" : "")}>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <img src={Array.isArray(p.images) ? p.images[0]?.src : ""} alt={p.name} className="h-8 w-8 rounded object-cover" />
                    <span className="font-medium text-slate-100">{p.name}</span>
                  </div>
                </td>
                <td className="px-4 py-3 font-mono text-xs text-slate-400">{p.sku}</td>
                <td className="px-4 py-3 text-center font-semibold">{p.stock}</td>
                <td className="px-4 py-3 text-center">
                  {p.stock === 0 ? (
                    <span className="rounded-full bg-red-500/15 px-2 py-0.5 text-[10px] font-bold uppercase text-red-400">Out</span>
                  ) : p.stock <= lowStockThreshold ? (
                    <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-bold uppercase text-amber-400">Low</span>
                  ) : (
                    <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold uppercase text-emerald-400">OK</span>
                  )}
                </td>
                <td className="px-4 py-3 text-right font-semibold text-gold">{formatPrice(p.price)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------------- Customers ---------------- */
function CustomersTab({ subscribers, orders }: { subscribers: any[]; orders: any[] }) {
  const [search, setSearch] = useState("");

  // Build customer list from subscribers + orders
  const customerMap = new Map<string, { email: string; name: string; orders: number; totalSpent: number; createdAt: string }>();

  subscribers.forEach((s) => {
    customerMap.set(s.email, { email: s.email, name: s.name || s.email.split("@")[0], orders: 0, totalSpent: 0, createdAt: s.createdAt });
  });

  orders.forEach((o) => {
    const existing = customerMap.get(o.email);
    if (existing) {
      existing.orders++;
      existing.totalSpent += o.total || 0;
    } else {
      customerMap.set(o.email, { email: o.email, name: o.customerName, orders: 1, totalSpent: o.total || 0, createdAt: o.createdAt });
    }
  });

  const customers = Array.from(customerMap.values()).filter(
    (c) => !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-serif text-3xl font-bold">Customers</h1>
        <p className="mt-1 text-sm text-slate-400">{customers.length} registered customers</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search customers…" className="w-full rounded-xl border border-white/10 bg-white/[0.03] py-2.5 pl-10 pr-4 text-sm outline-none focus:border-gold/50" />
      </div>

      <div className="overflow-x-auto rounded-2xl border border-white/10">
        <table className="w-full text-sm">
          <thead className="bg-white/[0.05] text-xs uppercase tracking-wide text-slate-400">
            <tr>
              <th className="px-4 py-3 text-left font-medium">Customer</th>
              <th className="px-4 py-3 text-left font-medium">Email</th>
              <th className="px-4 py-3 text-center font-medium">Orders</th>
              <th className="px-4 py-3 text-right font-medium">Total Spent</th>
              <th className="px-4 py-3 text-center font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {customers.length === 0 ? (
              <tr><td colSpan={5} className="px-4 py-12 text-center text-slate-500">No customers yet</td></tr>
            ) : (
              customers.map((c, i) => (
                <tr key={c.email} className={cn("border-t border-white/5", i % 2 === 0 ? "bg-white/[0.01]" : "")}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="grid h-8 w-8 place-items-center rounded-full bg-gold/20 text-xs font-bold text-gold">
                        {c.name.slice(0, 2).toUpperCase()}
                      </div>
                      <span className="font-medium text-slate-100">{c.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-400">{c.email}</td>
                  <td className="px-4 py-3 text-center">{c.orders}</td>
                  <td className="px-4 py-3 text-right font-semibold text-gold">{formatPrice(c.totalSpent)}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-bold uppercase", c.orders > 0 ? "bg-emerald-500/15 text-emerald-400" : "bg-slate-500/15 text-slate-400")}>
                      {c.orders > 0 ? "Active" : "Subscribed"}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------------- Payments ---------------- */
function PaymentsTab({ orders }: { orders: any[] }) {
  const successful = orders.filter((o) => o.paymentMethod === "Online" || o.status === "DELIVERED");
  const cod = orders.filter((o) => o.paymentMethod === "COD");
  const totalRevenue = orders.reduce((s, o) => s + (o.total || 0), 0);
  const codAmount = cod.reduce((s, o) => s + (o.total || 0), 0);
  const onlineAmount = totalRevenue - codAmount;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-serif text-3xl font-bold">Payments</h1>
        <p className="mt-1 text-sm text-slate-400">Transactions · COD · Online · Refunds</p>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 sm:grid-cols-4">
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <DollarSign className="h-5 w-5 text-emerald-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Total Revenue</p>
          <p className="font-serif text-xl font-bold">{formatPrice(totalRevenue)}</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <CreditCard className="h-5 w-5 text-blue-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Online</p>
          <p className="font-serif text-xl font-bold">{formatPrice(onlineAmount)}</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <IndianRupee className="h-5 w-5 text-amber-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">COD</p>
          <p className="font-serif text-xl font-bold">{formatPrice(codAmount)}</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <RotateCcw className="h-5 w-5 text-red-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Refunds</p>
          <p className="font-serif text-xl font-bold">₹0</p>
        </div>
      </div>

      {/* Transactions table */}
      <div className="overflow-x-auto rounded-2xl border border-white/10">
        <table className="w-full text-sm">
          <thead className="bg-white/[0.05] text-xs uppercase tracking-wide text-slate-400">
            <tr>
              <th className="px-4 py-3 text-left font-medium">Order #</th>
              <th className="px-4 py-3 text-left font-medium">Customer</th>
              <th className="px-4 py-3 text-center font-medium">Method</th>
              <th className="px-4 py-3 text-center font-medium">Status</th>
              <th className="px-4 py-3 text-right font-medium">Amount</th>
            </tr>
          </thead>
          <tbody>
            {orders.length === 0 ? (
              <tr><td colSpan={5} className="px-4 py-12 text-center text-slate-500">No transactions yet</td></tr>
            ) : (
              orders.map((o, i) => (
                <tr key={o.id} className={cn("border-t border-white/5", i % 2 === 0 ? "bg-white/[0.01]" : "")}>
                  <td className="px-4 py-3 font-mono text-xs text-gold">{o.orderNumber}</td>
                  <td className="px-4 py-3 text-slate-200">{o.customerName}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-bold uppercase", o.paymentMethod === "COD" ? "bg-amber-500/15 text-amber-400" : "bg-blue-500/15 text-blue-400")}>
                      {o.paymentMethod}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-bold uppercase", o.status === "DELIVERED" ? "bg-emerald-500/15 text-emerald-400" : o.status === "CANCELLED" ? "bg-red-500/15 text-red-400" : "bg-slate-500/15 text-slate-400")}>
                      {o.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-semibold text-gold">{formatPrice(o.total)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------------- Shipping ---------------- */
function ShippingTab() {
  const methods = [
    { name: "White-Glove Delivery", desc: "Complimentary worldwide", zones: "All zones", charge: "Free", partner: "DHL / Bluedart", active: true },
    { name: "Express Shipping", desc: "2-3 business days", zones: "India", charge: "₹250", partner: "Delhivery", active: true },
    { name: "International Express", desc: "7-14 business days", zones: "Worldwide", charge: "₹2,500", partner: "DHL Express", active: true },
    { name: "Standard International", desc: "14-21 business days", zones: "Worldwide", charge: "₹1,200", partner: "India Post", active: false },
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-serif text-3xl font-bold">Shipping</h1>
        <p className="mt-1 text-sm text-slate-400">Methods · zones · charges · delivery partners</p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {methods.map((m) => (
          <div key={m.name} className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <Truck className="h-5 w-5 text-gold" />
                <h3 className="font-serif text-base font-semibold text-slate-100">{m.name}</h3>
              </div>
              <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-bold uppercase", m.active ? "bg-emerald-500/15 text-emerald-400" : "bg-slate-500/15 text-slate-400")}>
                {m.active ? "Active" : "Inactive"}
              </span>
            </div>
            <p className="mt-2 text-xs text-slate-400">{m.desc}</p>
            <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
              <div><span className="text-slate-500">Zone:</span> <span className="text-slate-200">{m.zones}</span></div>
              <div><span className="text-slate-500">Charge:</span> <span className="text-gold">{m.charge}</span></div>
              <div><span className="text-slate-500">Partner:</span> <span className="text-slate-200">{m.partner}</span></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Reports ---------------- */
function ReportsTab({ orders, products }: { orders: any[]; products: any[] }) {
  const totalRevenue = orders.reduce((s, o) => s + (o.total || 0), 0);
  const avgOrderValue = orders.length ? Math.round(totalRevenue / orders.length) : 0;
  const totalUnits = products.reduce((s, p) => s + (p.stock || 0), 0);

  // Top selling (by reviewCount as proxy)
  const topProducts = [...products].sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0)).slice(0, 5);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-serif text-3xl font-bold">Reports & Analytics</h1>
          <p className="mt-1 text-sm text-slate-400">Sales · revenue · product performance</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => window.open("/api/admin/export?type=orders", "_blank")} className="flex items-center gap-1.5 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-slate-300 hover:border-gold/50 hover:text-gold">
            <Download className="h-3.5 w-3.5" /> Orders CSV
          </button>
          <button onClick={() => window.open("/api/admin/export?type=products", "_blank")} className="flex items-center gap-1.5 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-slate-300 hover:border-gold/50 hover:text-gold">
            <Download className="h-3.5 w-3.5" /> Products CSV
          </button>
          <button onClick={() => window.open("/api/admin/export?type=customers", "_blank")} className="flex items-center gap-1.5 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-slate-300 hover:border-gold/50 hover:text-gold">
            <Download className="h-3.5 w-3.5" /> Customers CSV
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 sm:grid-cols-4">
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <TrendingUp className="h-5 w-5 text-emerald-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Total Revenue</p>
          <p className="font-serif text-xl font-bold">{formatPrice(totalRevenue)}</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <ShoppingBag className="h-5 w-5 text-blue-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Total Orders</p>
          <p className="font-serif text-xl font-bold">{orders.length}</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <IndianRupee className="h-5 w-5 text-amber-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Avg Order Value</p>
          <p className="font-serif text-xl font-bold">{formatPrice(avgOrderValue)}</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <Package className="h-5 w-5 text-purple-400" />
          <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Stock Units</p>
          <p className="font-serif text-xl font-bold">{totalUnits}</p>
        </div>
      </div>

      {/* Top products */}
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
        <h2 className="mb-4 font-serif text-lg font-semibold">Top Performing Products</h2>
        <div className="space-y-3">
          {topProducts.map((p, i) => (
            <div key={p.id} className="flex items-center gap-3">
              <span className="font-serif text-lg font-bold text-gold/60">#{i + 1}</span>
              <img src={Array.isArray(p.images) ? p.images[0]?.src : ""} alt={p.name} className="h-10 w-8 rounded object-cover" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-100">{p.name}</p>
                <p className="text-xs text-slate-400">{p.reviewCount || 0} reviews · {p.rating || 5}★</p>
              </div>
              <span className="font-semibold text-gold">{formatPrice(p.price)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------------- CMS ---------------- */
function CMSTab() {
  const pages = [
    { name: "Homepage", desc: "Hero, categories, best sellers, collections", status: "Published" },
    { name: "Store Page", desc: "Full product listing with filters", status: "Published" },
    { name: "Journal", desc: "Editorial blog with 6 articles", status: "Published" },
    { name: "Order Tracking", desc: "Customer order lookup page", status: "Published" },
    { name: "Gift Card Balance", desc: "Gift card balance checker", status: "Published" },
    { name: "Admin Login", desc: "Admin authentication page", status: "Published" },
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-serif text-3xl font-bold">CMS</h1>
        <p className="mt-1 text-sm text-slate-400">Pages · banners · content management</p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {pages.map((p) => (
          <div key={p.name} className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <div>
              <h3 className="font-serif text-sm font-semibold text-slate-100">{p.name}</h3>
              <p className="text-xs text-slate-400">{p.desc}</p>
            </div>
            <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold uppercase text-emerald-400">{p.status}</span>
          </div>
        ))}
      </div>

      {/* Announcement bar content */}
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
        <h2 className="mb-3 font-serif text-lg font-semibold">Announcement Bar Messages</h2>
        <div className="space-y-2">
          {["Complimentary white-glove delivery, worldwide", "Handcrafted in Kashmir · Estd. 2009", "Use code ZARIYA10 for 10% off your first order", "Each piece takes 150+ hours of artisan needlework"].map((msg, i) => (
            <div key={i} className="flex items-center gap-2 rounded-lg bg-white/[0.02] px-3 py-2">
              <span className="font-mono text-xs text-gold">#{i + 1}</span>
              <span className="text-sm text-slate-300">{msg}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Settings ---------------- */
function SettingsTab() {
  const [form, setForm] = useState({
    storeName: BRAND.fullName,
    email: BRAND.email,
    phone: BRAND.phone,
    whatsapp: BRAND.whatsapp,
    address: BRAND.address,
    currency: "INR",
    gstRate: "5%",
    codEnabled: true,
    upiEnabled: false,
    cardEnabled: false,
    freeShipping: true,
  });
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [adminUsers, setAdminUsers] = useState<any[]>([]);
  const [showAddAdmin, setShowAddAdmin] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings", { credentials: "include" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data?.settings) {
          setForm((f) => ({ ...f, ...data.settings }));
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
    fetch("/api/admin/admin-users", { credentials: "include" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => { if (data?.users) setAdminUsers(data.users); })
      .catch(() => {});
  }, []);

  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }));

  const handleSave = async () => {
    setSaving(true);
    try {
      const r = await fetch("/api/admin/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
        credentials: "include",
      });
      if (r.ok) toast.success("Settings saved to database");
      else toast.error("Failed to save");
    } catch { toast.error("Network error"); }
    finally { setSaving(false); }
  };

  const handleDeleteAdmin = async (id: string) => {
    if (!confirm("Delete this admin user?")) return;
    try {
      await fetch(`/api/admin/admin-users?id=${id}`, { method: "DELETE", credentials: "include" });
      toast.success("Admin user deleted");
      setAdminUsers((prev) => prev.filter((u) => u.id !== id));
    } catch { toast.error("Failed"); }
  };

  const inputCls = "w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 outline-none focus:border-gold/50";

  if (loading) return <div className="grid place-items-center py-20"><Loader2 className="h-8 w-8 animate-spin text-gold" /></div>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-serif text-3xl font-bold">Settings</h1>
        <p className="mt-1 text-sm text-slate-400">Store · payment · shipping · security · admin users</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Store info */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <h2 className="mb-4 font-serif text-lg font-semibold">Store Information</h2>
          <div className="space-y-3">
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Store Name</label><input value={form.storeName} onChange={(e) => set("storeName", e.target.value)} className={inputCls} /></div>
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Email</label><input value={form.email} onChange={(e) => set("email", e.target.value)} className={inputCls} /></div>
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Phone</label><input value={form.phone} onChange={(e) => set("phone", e.target.value)} className={inputCls} /></div>
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">WhatsApp</label><input value={form.whatsapp} onChange={(e) => set("whatsapp", e.target.value)} className={inputCls} /></div>
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Address</label><textarea value={form.address} onChange={(e) => set("address", e.target.value)} rows={2} className={inputCls} /></div>
          </div>
        </div>

        {/* Tax & currency */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <h2 className="mb-4 font-serif text-lg font-semibold">Tax & Currency</h2>
          <div className="space-y-3">
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Currency</label><input value={form.currency} onChange={(e) => set("currency", e.target.value)} className={inputCls} /></div>
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">GST Rate</label><input value={form.gstRate} onChange={(e) => set("gstRate", e.target.value)} className={inputCls} /></div>
            <div className="flex items-center justify-between rounded-lg bg-white/[0.02] px-3 py-2">
              <span className="text-sm text-slate-300">Free Shipping (worldwide)</span>
              <Switch checked={form.freeShipping} onCheckedChange={(v) => set("freeShipping", v)} />
            </div>
          </div>
        </div>

        {/* Payment gateways */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <h2 className="mb-4 font-serif text-lg font-semibold">Payment Gateways</h2>
          <div className="space-y-2">
            <div className="flex items-center justify-between rounded-lg bg-white/[0.02] px-3 py-2">
              <span className="text-sm text-slate-300">Cash on Delivery (COD)</span>
              <Switch checked={form.codEnabled} onCheckedChange={(v) => set("codEnabled", v)} />
            </div>
            <div className="flex items-center justify-between rounded-lg bg-white/[0.02] px-3 py-2">
              <span className="text-sm text-slate-300">UPI / Razorpay</span>
              <Switch checked={form.upiEnabled} onCheckedChange={(v) => set("upiEnabled", v)} />
            </div>
            <div className="flex items-center justify-between rounded-lg bg-white/[0.02] px-3 py-2">
              <span className="text-sm text-slate-300">Credit / Debit Card</span>
              <Switch checked={form.cardEnabled} onCheckedChange={(v) => set("cardEnabled", v)} />
            </div>
          </div>
        </div>

        {/* Admin users & roles */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-serif text-lg font-semibold">Admin Users & Roles</h2>
            <button onClick={() => setShowAddAdmin(true)} className="flex items-center gap-1 rounded-full bg-gold/20 px-3 py-1 text-[10px] font-semibold text-gold hover:bg-gold/30">
              <Plus className="h-3 w-3" /> Add
            </button>
          </div>
          <div className="space-y-2">
            {adminUsers.map((u) => (
              <div key={u.id} className="flex items-center gap-2 rounded-lg bg-white/[0.02] px-3 py-2">
                {u.role === "SUPER_ADMIN" ? <Crown className="h-4 w-4 text-gold" /> : <Shield className="h-4 w-4 text-slate-400" />}
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-slate-100">{u.name}</p>
                  <p className="truncate text-xs text-slate-400">{u.email}</p>
                </div>
                <span className={cn("rounded-full px-2 py-0.5 text-[9px] font-bold uppercase", u.role === "SUPER_ADMIN" ? "bg-gold/20 text-gold" : "bg-slate-500/15 text-slate-400")}>{u.role === "SUPER_ADMIN" ? "Super Admin" : "Admin"}</span>
                {u.role !== "SUPER_ADMIN" && (
                  <button onClick={() => handleDeleteAdmin(u.id)} className="text-slate-500 hover:text-red-400"><Trash2 className="h-3.5 w-3.5" /></button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Save button */}
      <button
        onClick={handleSave}
        disabled={saving}
        className="flex items-center gap-2 rounded-full bg-gradient-to-r from-gold to-champagne px-6 py-2.5 text-xs font-semibold uppercase tracking-wide text-primary disabled:opacity-60"
      >
        {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
        {saving ? "Saving…" : "Save Settings"}
      </button>

      {/* Add Admin User Modal */}
      {showAddAdmin && (
        <AddAdminModal onClose={() => setShowAddAdmin(false)} onSaved={() => { setShowAddAdmin(false); fetch("/api/admin/admin-users", { credentials: "include" }).then((r) => r.json()).then((d) => d.users && setAdminUsers(d.users)); }} />
      )}
    </div>
  );
}

function AddAdminModal({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("ADMIN");
  const [saving, setSaving] = useState(false);
  const inputCls = "w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 outline-none focus:border-gold/50";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) { toast.error("All fields required"); return; }
    setSaving(true);
    try {
      const r = await fetch("/api/admin/admin-users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password, role }),
        credentials: "include",
      });
      const data = await r.json();
      if (!r.ok) { toast.error(data.error || "Failed"); return; }
      toast.success("Admin user created");
      onSaved();
    } catch { toast.error("Network error"); }
    finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-md rounded-3xl border border-white/10 bg-[hsl(352_30%_8%)] p-6">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-serif text-xl font-bold">Add Admin User</h2>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full text-slate-400 hover:bg-white/10"><X className="h-4 w-4" /></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Name *</label><input value={name} onChange={(e) => setName(e.target.value)} className={inputCls} /></div>
          <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Email *</label><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className={inputCls} /></div>
          <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Password *</label><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className={inputCls} /></div>
          <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Role</label>
            <select value={role} onChange={(e) => setRole(e.target.value)} className={inputCls}>
              <option value="ADMIN">Admin</option>
              <option value="SUPER_ADMIN">Super Admin</option>
            </select>
          </div>
          <div className="flex justify-end gap-3 border-t border-white/10 pt-4">
            <button type="button" onClick={onClose} className="rounded-full border border-white/15 px-5 py-2 text-xs font-semibold text-slate-300">Cancel</button>
            <button type="submit" disabled={saving} className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-gold to-champagne px-6 py-2 text-xs font-semibold text-primary disabled:opacity-60">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} {saving ? "Creating…" : "Create"}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

/* ---------------- Image Uploader ---------------- */
function ImageUploader({ images, onChange }: { images: string; onChange: (val: string) => void }) {
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  // images is a newline-separated string of URLs
  const imageList = images.split("\n").map((s) => s.trim()).filter(Boolean);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);

    const newUrls: string[] = [];
    for (const file of Array.from(files)) {
      // Validate image type
      if (!file.type.startsWith("image/")) {
        toast.error(`${file.name} is not an image`);
        continue;
      }
      // Validate size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error(`${file.name} is too large (max 5MB)`);
        continue;
      }

      // Convert to base64 data URL (for demo — in production, upload to S3/Cloudinary)
      const dataUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
      newUrls.push(dataUrl);
    }

    if (newUrls.length > 0) {
      const updated = [...imageList, ...newUrls].join("\n");
      onChange(updated);
      toast.success(`${newUrls.length} photo${newUrls.length !== 1 ? "s" : ""} uploaded`);
    }
    setUploading(false);
  };

  const removeImage = (idx: number) => {
    const updated = imageList.filter((_, i) => i !== idx).join("\n");
    onChange(updated);
    toast("Photo removed");
  };

  const moveImage = (idx: number, dir: "up" | "down") => {
    const newList = [...imageList];
    const target = dir === "up" ? idx - 1 : idx + 1;
    if (target < 0 || target >= newList.length) return;
    [newList[idx], newList[target]] = [newList[target], newList[idx]];
    onChange(newList.join("\n"));
  };

  return (
    <div className="space-y-3">
      {/* Upload zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          handleFiles(e.dataTransfer.files);
        }}
        onClick={() => fileRef.current?.click()}
        className={cn(
          "cursor-pointer rounded-xl border-2 border-dashed p-6 text-center transition-all",
          dragOver ? "border-gold bg-gold/10" : "border-white/15 hover:border-gold/40 hover:bg-white/[0.02]"
        )}
      >
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />
        {uploading ? (
          <div className="flex flex-col items-center gap-2">
            <Loader2 className="h-6 w-6 animate-spin text-gold" />
            <p className="text-xs text-slate-400">Uploading…</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <div className="grid h-12 w-12 place-items-center rounded-full bg-gold/10">
              <Plus className="h-5 w-5 text-gold" />
            </div>
            <p className="text-sm font-medium text-slate-200">Click to upload or drag & drop</p>
            <p className="text-[11px] text-slate-500">PNG, JPG, WebP · max 5MB each · multiple files allowed</p>
          </div>
        )}
      </div>

      {/* URL paste fallback */}
      <details className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
        <summary className="cursor-pointer text-[11px] font-semibold uppercase tracking-wide text-slate-400">
          Or paste image URL manually
        </summary>
        <input
          type="text"
          placeholder="/images/products/new-product.png"
          className="mt-2 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs text-slate-100 outline-none focus:border-gold/50"
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              const val = (e.target as HTMLInputElement).value.trim();
              if (val) {
                onChange([...imageList, val].join("\n"));
                (e.target as HTMLInputElement).value = "";
                toast.success("Image URL added");
              }
            }
          }}
        />
      </details>

      {/* Preview grid */}
      {imageList.length > 0 && (
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {imageList.map((src, i) => (
            <div key={i} className="group relative aspect-square overflow-hidden rounded-lg border border-white/10 bg-white/5">
              <img src={src} alt={`Product photo ${i + 1}`} className="h-full w-full object-cover" />
              {/* Overlay */}
              <div className="absolute inset-0 bg-black/50 opacity-0 transition-opacity group-hover:opacity-100">
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-1">
                  {/* Move buttons */}
                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); moveImage(i, "up"); }}
                      disabled={i === 0}
                      className="grid h-6 w-6 place-items-center rounded bg-white/20 text-white disabled:opacity-30 hover:bg-white/30"
                    >
                      <ArrowLeft className="h-3 w-3 rotate-[-90deg]" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); moveImage(i, "down"); }}
                      disabled={i === imageList.length - 1}
                      className="grid h-6 w-6 place-items-center rounded bg-white/20 text-white disabled:opacity-30 hover:bg-white/30"
                    >
                      <ArrowLeft className="h-3 w-3 rotate-90" />
                    </button>
                  </div>
                  {/* Delete */}
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); removeImage(i); }}
                    className="grid h-6 w-6 place-items-center rounded bg-red-500/80 text-white hover:bg-red-500"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              </div>
              {/* Order badge */}
              <span className="absolute left-1 top-1 grid h-5 w-5 place-items-center rounded-full bg-gold text-[9px] font-bold text-primary">
                {i + 1}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Image count */}
      {imageList.length > 0 && (
        <p className="text-[11px] text-slate-500">
          {imageList.length} photo{imageList.length !== 1 ? "s" : ""} · first photo will be used as main image
        </p>
      )}
    </div>
  );
}

/* ---------------- Hero Slides (Banner Management) ---------------- */
function HeroSlidesTab() {
  const [slides, setSlides] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/hero-slides", { credentials: "include" });
      if (r.ok) {
        const d = await r.json();
        setSlides(d.slides);
      }
    } catch {}
    setLoading(false);
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => { await load(); if (cancelled) return; })();
    return () => { cancelled = true; };
  }, [load]);

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this hero slide?")) return;
    try {
      await fetch(`/api/admin/hero-slides?id=${id}`, { method: "DELETE", credentials: "include" });
      toast.success("Slide deleted");
      load();
    } catch { toast.error("Failed"); }
  };

  const toggleActive = async (id: string, active: boolean) => {
    try {
      await fetch("/api/admin/hero-slides", {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, active: !active }), credentials: "include",
      });
      toast.success(active ? "Slide hidden" : "Slide visible");
      load();
    } catch {}
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-serif text-3xl font-bold">Hero Banners</h1>
          <p className="mt-1 text-sm text-slate-400">Manage homepage hero slides · images, titles, badges</p>
        </div>
        <button onClick={() => { setEditing(null); setShowForm(true); }} className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-gold to-champagne px-4 py-2 text-xs font-semibold uppercase tracking-wide text-primary">
          <Plus className="h-4 w-4" /> Add Slide
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-12"><Loader2 className="h-8 w-8 animate-spin text-gold" /></div>
      ) : slides.length === 0 ? (
        <EmptyState icon={Image} title="No hero slides" subtitle="Add slides to show on the homepage hero section." />
      ) : (
        <div className="space-y-3">
          {slides.map((s, i) => (
            <motion.div key={s.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: i * 0.05, ease: EASE }} className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03]">
              <div className="flex gap-4 p-4">
                {/* Image */}
                <div className="relative h-24 w-32 flex-none overflow-hidden rounded-lg">
                  <img src={s.image} alt={s.title || "hero"} className="h-full w-full object-cover" />
                  {s.badge && <span className="absolute left-1 top-1 rounded bg-gold px-1.5 py-0.5 text-[8px] font-bold uppercase text-primary">{s.badge}</span>}
                </div>
                {/* Content */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-slate-500">#{s.order}</span>
                    <span className={cn("rounded-full px-2 py-0.5 text-[9px] font-bold uppercase", s.active ? "bg-emerald-500/15 text-emerald-400" : "bg-slate-500/15 text-slate-400")}>{s.active ? "Visible" : "Hidden"}</span>
                  </div>
                  <h3 className="mt-1 truncate font-serif text-base font-semibold text-slate-100">{s.title}</h3>
                  <p className="truncate text-xs text-slate-400">{s.subtitle}</p>
                  <p className="mt-1 text-[10px] text-slate-500">Eyebrow: {s.eyebrow}</p>
                </div>
                {/* Actions */}
                <div className="flex flex-none flex-col gap-1">
                  <button onClick={() => { setEditing(s); setShowForm(true); }} className="flex items-center gap-1 rounded-md bg-white/5 px-2.5 py-1 text-[10px] font-semibold text-slate-300 hover:bg-gold/20 hover:text-gold">
                    <Pencil className="h-3 w-3" /> Edit
                  </button>
                  <button onClick={() => toggleActive(s.id, s.active)} className="rounded-md bg-white/5 px-2.5 py-1 text-[10px] font-semibold text-slate-300 hover:bg-amber-500/20 hover:text-amber-400">
                    {s.active ? "Hide" : "Show"}
                  </button>
                  <button onClick={() => handleDelete(s.id)} className="flex items-center gap-1 rounded-md bg-white/5 px-2.5 py-1 text-[10px] font-semibold text-slate-300 hover:bg-red-500/20 hover:text-red-400">
                    <Trash2 className="h-3 w-3" /> Delete
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {showForm && (
        <HeroSlideFormModal
          slide={editing}
          onClose={() => { setShowForm(false); setEditing(null); }}
          onSaved={() => { setShowForm(false); setEditing(null); load(); }}
        />
      )}
    </div>
  );
}

function HeroSlideFormModal({ slide, onClose, onSaved }: { slide: any | null; onClose: () => void; onSaved: () => void }) {
  const isEdit = !!slide;
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    image: slide?.image || "",
    eyebrow: slide?.eyebrow || "Handcrafted in Kashmir · Estd. 2009",
    title: slide?.title || "",
    subtitle: slide?.subtitle || "",
    buttonText: slide?.buttonText || "Shop Collection",
    buttonLink: slide?.buttonLink || "/store",
    badge: slide?.badge || "",
    order: slide?.order ?? 0,
    active: slide?.active !== false,
  });
  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }));
  const inputCls = "w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 outline-none focus:border-gold/50";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.image || !form.title) { toast.error("Image and title required"); return; }
    setSaving(true);
    try {
      const method = isEdit ? "PATCH" : "POST";
      const body = isEdit ? { id: slide.id, ...form, badge: form.badge || null } : { ...form, badge: form.badge || null };
      const r = await fetch("/api/admin/hero-slides", { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), credentials: "include" });
      const data = await r.json();
      if (!r.ok) { toast.error(data.error || "Failed"); return; }
      toast.success(isEdit ? "Slide updated" : "Slide created");
      onSaved();
    } catch { toast.error("Network error"); }
    finally { setSaving(false); }
  };

  const handleImageUpload = (files: FileList | null) => {
    if (!files || !files[0]) return;
    const file = files[0];
    if (!file.type.startsWith("image/")) { toast.error("Not an image"); return; }
    const reader = new FileReader();
    reader.onload = () => set("image", reader.result as string);
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-h-[90vh] w-full max-w-lg overflow-y-auto scrollbar-lux rounded-3xl border border-white/10 bg-[hsl(352_30%_8%)] p-6">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-serif text-xl font-bold">{isEdit ? "Edit Hero Slide" : "Add Hero Slide"}</h2>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full text-slate-400 hover:bg-white/10"><X className="h-4 w-4" /></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Image upload */}
          <div>
            <label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Banner Image *</label>
            {form.image ? (
              <div className="relative mb-2 overflow-hidden rounded-lg">
                <img src={form.image} alt="Banner preview" className="aspect-[16/9] w-full object-cover" />
                <button type="button" onClick={() => set("image", "")} className="absolute right-2 top-2 grid h-7 w-7 place-items-center rounded-full bg-black/60 text-white hover:bg-red-500"><X className="h-3.5 w-3.5" /></button>
              </div>
            ) : (
              <div onClick={() => document.getElementById("hero-img-upload")?.click()} className="cursor-pointer rounded-lg border-2 border-dashed border-white/15 p-6 text-center hover:border-gold/40">
                <Image alt="" className="mx-auto h-8 w-8 text-slate-500" />
                <p className="mt-2 text-xs text-slate-400">Click to upload banner image</p>
                <input id="hero-img-upload" type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e.target.files)} />
              </div>
            )}
            <input value={form.image.startsWith("data:") ? "" : form.image} onChange={(e) => set("image", e.target.value)} placeholder="/images/hero/your-image.png" className={cn(inputCls, "mt-2")} />
          </div>
          <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Title *</label><input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="Every Thread, A Story" className={inputCls} /></div>
          <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Subtitle</label><textarea value={form.subtitle} onChange={(e) => set("subtitle", e.target.value)} rows={2} className={inputCls} /></div>
          <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Eyebrow Label</label><input value={form.eyebrow} onChange={(e) => set("eyebrow", e.target.value)} className={inputCls} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Badge (optional)</label><input value={form.badge} onChange={(e) => set("badge", e.target.value)} placeholder="New Arrival / Coming Soon" className={inputCls} /></div>
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Order</label><input type="number" value={form.order} onChange={(e) => set("order", Number(e.target.value))} className={inputCls} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Button Text</label><input value={form.buttonText} onChange={(e) => set("buttonText", e.target.value)} className={inputCls} /></div>
            <div><label className="mb-1 block text-[11px] font-semibold uppercase text-slate-400">Button Link</label><input value={form.buttonLink} onChange={(e) => set("buttonLink", e.target.value)} className={inputCls} /></div>
          </div>
          <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={form.active} onChange={(e) => set("active", e.target.checked)} className="h-4 w-4 accent-gold" /><span className="text-xs text-slate-300">Visible on homepage</span></label>
          <div className="flex justify-end gap-3 border-t border-white/10 pt-4">
            <button type="button" onClick={onClose} className="rounded-full border border-white/15 px-5 py-2 text-xs font-semibold text-slate-300">Cancel</button>
            <button type="submit" disabled={saving} className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-gold to-champagne px-6 py-2 text-xs font-semibold text-primary disabled:opacity-60">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} {saving ? "Saving…" : isEdit ? "Update" : "Create"}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
